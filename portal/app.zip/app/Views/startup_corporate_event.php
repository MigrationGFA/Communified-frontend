
      <!-- BEGIN: Content-->
      <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
          <!-- Coming soon page-->
          <div class="misc-wrapper"><a class="brand-logo" href="<?php echo base_url(); ?>gfa/dashboard">
             
            <div class="misc-inner p-2 p-sm-3">
              <div class="w-100 text-center">
                <h2 class="mb-1">Welcome! 🚀</h2>
                <p class="mb-3">Registeration is on-going, you will be notified soon as the registration is closed to start connection.</p>
                <form class="row row-cols-md-auto row justify-content-center align-items-center m-0 mb-2 gx-3" action="javascript:void(0)">
                
                </form>
            </div>
          </div>
          <!-- / Coming soon page-->
        </div>
      </div>
    </div>
    <!-- END: Content-->



   
  
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

   