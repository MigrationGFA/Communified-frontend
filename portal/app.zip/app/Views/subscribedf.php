<div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        
        <div class="content-body">
            <div class="auth-wrapper auth-cover">
                
  <div class="auth-inner row m-0">
    <!-- Brand logo-->
    
    <!-- /Brand logo-->

    <!-- Register-->
    <div class="col-lg-12 d-flex align-items-center auth-bg px-2 px-sm-3 px-lg-5 pt-3	">
      <div class="width-1000 mx-auto">
        <div class="bs-stepper register-multi-steps-wizard shadow-none">
        
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Select plan to continue</h4>
      </div>
      <div class="card-body">
        <div class="row custom-options-checkable g-1">
		    <div class="col-md-3">
            <input
              class="custom-option-item-check"
              type="radio"
              name="customOptionsCheckableRadiosWithIcon"
              id="customOptionsCheckableRadiosWithIcon3"
              value=""
            />
            <label class="custom-option-item text-center p-1" for="customOptionsCheckableRadiosWithIcon3">
               <i data-feather="play" class="font-large-1 mb-75"></i>
              <span class="custom-option-item-title h4 d-block">Benefit</span>
              
	 
			   <span class="plan-price">
                        <sup class="font-medium-1 fw-bold text-primary"></sup>
                        <span class="pricing-value fw-bolder text-primary">&nbsp;</span>
                        <sub class="pricing-duration text-body font-medium-1 fw-bold"></sub>
               </span>
			  
			  <small><center>
			  <table border="1">
			  
			  <tr>
			  <td align="center">Investor recommendations</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Recommendations Duration</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor profile type</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Introductions</td>
			  </tr>
			  
			  <tr>
			  <td align="center">GFA Store</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Memtorship program</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Pitchdeck template</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free course</td>
			  </tr>
			  
			  <tr>
			  <td align="center">One on one Consultation</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Business model template</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Cap table management</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor meetings

</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Outreach strategy
</td>
			  </tr>
			  
			  
			  
			 
			  <tr>
			  <td align="center">Bi-monthly reviews</td>
			  </tr>
			  
	
			  
			  <tr>
			  <td align="center">Valuation simulation</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Media Interview/profile</td>
			  </tr>
			  <tr>
			  <td align="center">Deal Room
</td>
			  </tr>
			  <tr>
			  <td align="center">Business partnership intro
</td>
			  </tr>
			   <tr>
			  <td align="center">Dedicated Fundraising Consultant</td>
			  </tr>
			  
			  
			  </table></small>
			  </center>
			  
					  
            </label>
          </div>
		
		 <div class="col-md-3">
            <input
              class="custom-option-item-check"
              type="radio"
              name="customOptionsCheckableRadiosWithIcon"
              id="customOptionsCheckableRadiosWithIcon2"
              value=""
            />
            <label class="custom-option-item text-center text-center p-1" for="customOptionsCheckableRadiosWithIcon2">
              <i data-feather="user" class="font-large-1 mb-75"></i>
              <span class="custom-option-item-title h4 d-block">Free</span>
			   <span class="plan-price">
                        <sup class="font-medium-1 fw-bold text-primary">$</sup>
                        <span class="pricing-value fw-bolder text-primary">0</span>
                        <sub class="pricing-duration text-body font-medium-1 fw-bold">/month</sub>
               </span>
              <small>
			  <center>
			  <table border="1">
			  
			  <tr>
			  <td align="center">One weekly</td>
			  </tr>
			  
			  <tr>
			  <td align="center">One month</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Linkedin profile</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Email outreach template</td>
			  </tr>
			  
			  <tr>
			  <td align="center">$5 store voucher</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free access</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X
			  </td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X
</td>
			  </tr>
			  <tr>
			  <td align="center">X
</td>
			  </tr>
			  
			  
			  </table>
			  </center>
			  </small>
			    <br>
			  <br>
			  
			  
			  <a href="<?php echo base_url(); ?>gfa/complete_sub/?radio=free" class="btn btn-primary w-100" tabindex="4">Continue for Free</a>
			  <br>
			  <br>
			  </small>
			   
            </label>
          </div>	
		 <div class="col-md-3">
            <input
              class="custom-option-item-check"
              type="radio"
              name="customOptionsCheckableRadiosWithIcon"
              id="customOptionsCheckableRadiosWithIcon2"
              value=""
            />
            <label class="custom-option-item text-center text-center p-1" for="customOptionsCheckableRadiosWithIcon2">
              <i data-feather="user" class="font-large-1 mb-75"></i>
              <span class="custom-option-item-title h4 d-block">Premium Plan</span>
              <small>
			   <span class="plan-price">
                        <sup class="font-medium-1 fw-bold text-primary" style="font-size:2em;">N</sup>
                        <span class="pricing-value fw-bolder text-primary" style="font-size:30px;">333,000</span>
                        <sub class="pricing-duration text-body font-medium-1 fw-bold" style="font-size:2em;">/Yr</sub>
               </span>
			   <center><br>
			  <table border="1">
			  
			  <tr>
			  <td align="center">Two weekly</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Two  months</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor email</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Warm Investor Intros</td>
			  </tr>
			  
			  <tr>
			  <td align="center">$50 store voucher</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free access</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free pitch deck template</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Full Investor readiness course</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free scheduled consultation</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free business model template</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Cap table management</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor meeting prep</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X
			  </td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X</td>
			  </tr>
			  
			  <tr>
			  <td align="center">X
</td>
			  </tr>
			  <tr>
			  <td align="center">X
</td>
			  </tr>
			  
			  
			  </table></small>
			  </center>
			  
			  </small>
			   <br>
			  <br>
			  
			  
			  <a href="<?php echo base_url(); ?>gfa/complete_sub/?radio=premium" class="btn btn-primary w-100 payForm" tabindex="4">Pay to Continue</a>
			  <br>
			  <br>
            </label>
          </div>
		
		
          <div class="col-md-3">
            <input
              class="custom-option-item-check"
              type="radio"
              name="customOptionsCheckableRadiosWithIcon"
              id="customOptionsCheckableRadiosWithIcon1"
              checked
            />
            <label class="custom-option-item text-center p-1" for="customOptionsCheckableRadiosWithIcon1">
              <i data-feather="user" class="font-large-1 mb-75"></i>
              <span class="custom-option-item-title h4 d-block">Assisted Fundraisimg </span>
             
			   <span class="plan-price">
                        <div style="color:#7367F0; font-weight:bold;">CONTACT US</div>
                </span>
				<br>

				
				 <small> <table border="1">
			  
			  <tr>
			  <td align="center">Intros to 200+ VCs & angels
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">One year
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor email + phone
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Warm Investor Intros
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">$100 store voucher
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free access</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Pitch deck dev/review
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Full Investor readiness course
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free scheduled consultation
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Free business model template
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Cap table management</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor meeting prep</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Investor Outreach Strategy
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Dedicated Fundraising</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Bi-monthly reviews

			  </td>
			  </tr>
			  
			  <tr>
			  <td align="center">Valuation simulation
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Media Interview/profile
</td>
			  </tr>
			  
			  <tr>
			  <td align="center">Deal Room

</td>
			  </tr>
			  <tr>
			  <td align="center">Business partnership intro

</td>
			  </tr>
			  
			  
			  </table></small>
			  
			  <br>
			  <br>
			  
			  
			   <a href="https://getfundedafrica.com/contact-us.php" target="_blank" class="btn btn-primary w-100" tabindex="4">Contact</a>
			  <br>
			  <br>
			 </small>
			
            </label>
          </div>

         
         
        </div>
      </div>
	  
    </div>
  </div>
		
	
	

        </div>
      </div>
    </div>


    <script>
     $(function(){
         var valuex =    $(".showValue").val() ;
          $('#myForm').on('click', function () {
        var value = $("[name=radio]:checked").val();

         var valuex =    $(".showValue").val(value) ;
    //   if(value == "pay"){
    //   window.open("<?php echo base_url(); ?>gfa/complete_sub/"+value, "_self");
    //   }
    //   if(value == "free"){
    //   window.open("<?php echo base_url(); ?>gfa/complete_sub/"+value, "_self");
    //   }
    //   if(value == "payasugo"){
    //   window.open("<?php echo base_url(); ?>gfa/complete_sub/"+value, "_self");
    //   }
    });
    
    // $(".btnTest").submit(function () {
    
    //     window.open("<?php echo base_url(); ?>gfa/complete_sub/"+valuex, "_self"); 
    // });
         
});
    </script>