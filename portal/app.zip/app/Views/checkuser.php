
<div class="user-area pt-100 pb-70">
<div class="container">
<div class="row align-items-center">

<?php if(!empty($message)){ echo $message; } ?>
<?php if(!empty($data)){ echo $data; } ?>
</div>
</div>
</div>