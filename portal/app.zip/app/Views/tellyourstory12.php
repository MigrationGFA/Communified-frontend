
    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">
            
<section class="app-user-view-account">
  <div class="row">
  

    <!-- User Content -->
    <div class="col-xl-6 col-lg-7 col-md-7 order-0 order-md-1">
     
	 
	 
<!-- payment methods -->
      <div class="card">
        
        <div class="card-body">
           <center>
				  <iframe src="https://www.youtube.com/embed/QtfUF4AOznE" frameborder="0" allowfullscreen class="video1" height="350px" width="420px"></iframe>
                  </center>



      </div>
      <!-- / payment methods -->
</div>
    



   </div>
    <!--/ User Content -->
  

    <!-- User Content -->
    <div class="col-xl-6 col-lg-7 col-md-7 order-0 order-md-1">
     
	 
	 
<!-- payment methods -->
      <div class="card">
        <div class="card-header">
          <h4 class="card-title mb-50">Tell Your Story</h4>
          <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addNewCard">
            <i data-feather="plus"></i>
            <span>Add Your Story</span>
          </button>
        </div>
        <div class="card-body">
          <div class="added-cards">
            <div class="cardMaster rounded border p-2 mb-1">
              <div class="d-flex justify-content-between flex-sm-row flex-column">
                <div class="card-information">
                  <img
                    class="mb-1 img-fluid"
                    src="../../../app-assets/images/icons/payments/bb.png"
                    alt="Master Card"
                  />
                  <div class="d-flex align-items-center mb-50">
				  <h4 class="mb-0">Balance Bowl Nigeria Ltd</h4>
                  </div>
                  <br><span class="card-number">Andrea Kamara-Dunbar is the founder/CEO of Balance Bowl Nigeria Ltd, a health tech company using technology to provide lifestyle support for those who want to make a change and live healthier. It has locations in Lagos, Nigeria & Maryland, USA.</span>
				 
				  <div class="d-flex pt-2">
              <a href="javascript:;" class="btn btn-primary me-1" data-bs-target="#editUser" data-bs-toggle="modal">
                View Details
              </a>
             
            </div>
                </div>
               
			   
            </div>
          </div>
        </div>
      </div>
      <!-- / payment methods -->
</div>
    



   </div>
    <!--/ User Content -->
  </div>
</section>


<section class="app-user-view-account">
  <div class="row">

    <!-- User Content -->
    <div class="col-xl-6 col-lg-7 col-md-7 order-0 order-md-1">
     
	 
	 
<!-- payment methods -->
      <div class="card">
        <div class="card-header">
          <h4 class="card-title mb-50">Story we have told</h4>
          
        </div>
        <div class="card-body">
          <div class="added-cards">
            <div class="cardMaster rounded border p-2 mb-1">
              <div class="d-flex justify-content-between flex-sm-row flex-column">
                <div class="card-information">
                  <img
                    class="mb-1 img-fluid"
                     src="../../../app-assets/images/icons/payments/bb.png"
                    alt="Balance Bowl"
                  />
                  <div class="d-flex align-items-center mb-50">
				  <h4 class="mb-0">Balance Bowl Nigeria Ltd</h4>
                  </div>
                  <br><span class="card-number">Andrea Kamara-Dunbar is the founder/CEO of Balance Bowl Nigeria Ltd, a health tech company using technology to provide lifestyle support for those who want to make a change and live healthier. It has locations in Lagos, Nigeria & Maryland, USA.<br><br>
                  
                </span>
				 
				  <div class="d-flex pt-2">
              <a href="javascript:;" class="btn btn-primary me-1" data-bs-target="#editUser" data-bs-toggle="modal">
                View Details
              </a>
             
            </div>
                </div>
               
			   
            </div>
          </div>
        </div>
      </div>
      <!-- / payment methods -->
</div>
    

   </div>
    <!--/ User Content -->


    <!-- User Content -->
    <div class="col-xl-6 col-lg-7 col-md-7 order-0 order-md-1">
     
	 
	 
<!-- payment methods -->
      <div class="card">
      
        <div class="card-body">
          <div class="added-cards">
            <div class="cardMaster rounded border p-2 mb-1">
              <div class="d-flex justify-content-between flex-sm-row flex-column">
                <div class="card-information">
                  <center>
				  <iframe src="https://www.youtube.com/embed/QtfUF4AOznE" frameborder="0" allowfullscreen class="video1" height="350px" width="420px"></iframe>
                  </center>
				 
                </div>
               
			   
            </div>
          </div>
        </div>
      </div>
      <!-- / payment methods -->
</div>
    

   </div>
    <!--/ User Content -->
  </div>
</section>
          <!-- Edit User Modal -->
        </div>
      </div>
    </div>
    <!-- END: Content-->


   
  
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

   